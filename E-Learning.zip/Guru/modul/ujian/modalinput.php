<!-- Modal A -->
<div class="modal fade" id="pilihanA" tabindex="-1" role="dialog" aria-labelledby="pilihanA">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="pilihanA">Pilihan A</h4>
      </div>
      <div class="modal-body">
        <textarea name="p1" id="ckeditor1"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal B -->
<div class="modal fade" id="pilihanB" tabindex="-1" role="dialog" aria-labelledby="pilihanB">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="pilihanB">Pilihan B</h4>
      </div>
      <div class="modal-body">
        <textarea name="p2" id="ckeditor2"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal C -->
<div class="modal fade" id="pilihanC" tabindex="-1" role="dialog" aria-labelledby="pilihanC">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="pilihanC">Pilihan C</h4>
      </div>
      <div class="modal-body">
        <textarea name="p3" id="ckeditor3"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal D -->
<div class="modal fade" id="pilihanD" tabindex="-1" role="dialog" aria-labelledby="pilihanD">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="pilihanD">Pilihan D</h4>
      </div>
      <div class="modal-body">
        <textarea name="p4" id="ckeditor4"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal E -->
<div class="modal fade" id="pilihanE" tabindex="-1" role="dialog" aria-labelledby="pilihanE">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="pilihanE">Pilihan E</h4>
      </div>
      <div class="modal-body">
        <textarea name="p5" id="ckeditor5"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>